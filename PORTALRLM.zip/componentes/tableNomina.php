<table class="table table-striped table-hover" id="DataTableNomina">
  <thead class="text-center">
    <tr>
      <th scope="col" class="item-admin">Identificacion</th>
      <th scope="col" class="item-admin">Empresa</th>
      <th scope="col">Mes</th>
      <th scope="col">Fechas</th>
      <th scope="col">Total devengado</th>
      <th scope="col">Total Deducido</th>
      <th scope="col">Neto a pagar</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody class="text-center" id="tblDashboardVolantes">
    
  </tbody>
</table>