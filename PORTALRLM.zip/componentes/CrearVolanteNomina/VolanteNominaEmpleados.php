
            <div class="card-body">
                    <div class="row container-fluid d-flex  align-items-center">
                        <h6 class="text-center">DATOS DEL EMPLEADO</h6>
                    </div>
            
                    <div class="contaier-fluid">
                        <form id="frmCrearNomina" class="mt-4">
                            <div class="row" id="">
                                <div class="col-md-6">
                                <!--Empresa-->
                                <div class="form-group">
                                    <label for="">NOMBRE DEL EMPLEADO</label>
                                    <select
                                    class="form-control"
                                    id="selectEmpleado"
                                    name="selectEmpleado"
                                    ></select>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <!--Empresa-->
                                <div class="form-group">
                                    <label for="">EMPRESA</label>
                                    <select class="form-control" id="selectEmpresas" name=""></select>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <!--tipo de documento-->
                                <div class="form-group">
                                    <label for="">TIPO DE DOCUMENTO</label>
                                    <select
                                    class="form-control"
                                    id="tipoDocumento"
                                    name="tipoDocumento"
                                    ></select>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <div class="form-group">
                                    <label for="campo5">NUMERO DE DOCUMENTO</label>
                                    <!--Numero de identificacion --->
                                    <input
                                    type="text"
                                    class="form-control"
                                    id="numeroDocumento"
                                    name="numeroDocumento"
                                    />
                                </div>
                                </div>
                                <div class="col-md-6">
                                <!--Cargo del empleado-->
                                <div class="form-group">
                                    <label for="">PERFIL O CARGO</label>
                                    <select class="form-control" id="Perfiles" name="Perfiles"></select>
                                </div>
                                </div>
                                <div class="col-md-6">
                                <div class="form-group">
                                <label for="campo5">Salario </label>
                                <!--Salario empleado --->
                                <input
                                    type="text"
                                    class="form-control"
                                    id="salarioEmpleado"
                                    name="salarioEmpleado"
                                />
                                </div>
                            </div>
                            </div>
                            
                            <input
                                type="text"
                                class="form-control"
                                id="id_empleado"
                                name="id_empleado"
                                style="display: none"
                            />
                        </form>

                    </div>
                </div>