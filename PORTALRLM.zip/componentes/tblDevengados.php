<table class=" table table-striped table-hover" id="tblDevengados">
  <thead class="text-center">
    <tr>
      <th scope="col">DESCRIPCION </th>
      <th scope="col">DEDUCCIONES</th>
      <th scope="col">DEVENGADO</th>
      <th scope="col">ACCION</th>
    </tr>
  </thead>
  <tbody class="text-center" id="FilaDevengado">
  </tbody>
  <tbody class="text-center" id="FilaDeduccion">
  </tbody>
</table>