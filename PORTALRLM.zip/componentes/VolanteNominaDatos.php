<div class="card-nomina card mt-2">
                <div class="card-body">
                    <div class="row container-fluid d-flex  align-items-center">
                        <h6 class="text-center">DATOS DE NOMINA</h6>
                    </div>
                    <div class="contaier-fluid">
                        <form id="" class="mt-4">
                            <div class="row" id="">
                                <div class="col-md-4">
                                <!--Empresa-->
                                <div class="form-group">
                                    <label for="">AÑO</label>
                                    <select
                                    class="form-control"
                                    id="selectAño"
                                    name="selectAño"
                                    ></select>
                                </div>
                                </div>
                                <div class="col-md-4">
                                <!--Empresa-->
                                <div class="form-group">
                                    <label for="">MES</label>
                                    <select
                                    class="form-control"
                                    id="selectMes"
                                    name="selectMes"
                                    >
                                    </select>
                                </div>
                                </div>
                                <div class="col-md-4">
                                <!--tipo de documento-->
                                <div class="form-group">
                                    <label for="">PERIODO</label>
                                    <select class="form-control" id="selectMes" name="selectMes" >
                                        <option value="">SELECCIONE UN PERIODO DEL AÑO</option>
                                        <option value="1">1 - 15</option>
                                        <option value="2">16 - 30</option>
                                    </select>
                                </div>
                                </div>
                            </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>